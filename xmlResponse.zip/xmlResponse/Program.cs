﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Xml;

namespace xmlResponse
{
    class Program
    {
        static void Main(string[] args)
        {
            GetXmlRespond();
        }

        private static XmlDocument GetXmlRespond()
        {
            string destinationUrl = "https://xmldev.dotwconnect.com/gatewayV4.dotw?WSDL";
            string requestXml = "<customer><username>MarsT</username><password>63f767150e66df0b4c0dee44f564ae28</password><id>1720035</id><source>1</source><request command ='gettransferpickupdropofflocationsids'></request></customer>";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(destinationUrl);
            request.Headers["Authorization"] = "Basic " + Convert.ToBase64String(Encoding.Default.GetBytes("API_TEST_NR:Testnol1$"));
            byte[] bytes;
            bytes = System.Text.Encoding.ASCII.GetBytes(requestXml);
            request.Method = "POST";
            request.ContentLength = bytes.Length;
            //request.Connection = "keep-alive";
            request.ContentType = "text/xml; UTF-8";
            request.KeepAlive = true;
            request.Timeout = 2000;
            request.MediaType = "text/xml; UTF-8";
            Stream requestStream = request.GetRequestStream();
            requestStream.Write(bytes, 0, bytes.Length);
            requestStream.Close();
            HttpWebResponse response;
            Stream responseStream;
            using (response = (HttpWebResponse)request.GetResponse())
            {
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    responseStream = response.GetResponseStream();
                    XmlReader reader = new XmlTextReader(responseStream);
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.Load(reader);
                    xmlDoc.Save(Console.Out);
                    // Console.WriteLine("asa");
                    try { reader.Close(); }
                    catch { }
                    try { responseStream.Close(); }
                    catch { }
                    try { response.Close(); }
                    catch { }
                    return xmlDoc;
                }
            }
            try { response.Close(); }
            catch { }
            return null;
        }
    }
}
